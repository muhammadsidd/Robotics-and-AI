#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include<vector>
#define N 5 

using namespace std;
double d = 0;
void multiply(vector<vector<double>> &mata, vector<vector<double>> &matb, vector<vector<double>> &res) 
{   
    res.resize(N);
    for(int i=0; i< N; i++){
        res.at(i).resize(N);
    }
    for (int i = 0; i < N; i++) 
    { for (int j = 0; j < N; j++) 
        { res.at(i).at(j) = 0; 
            for (int k = 0; k < N; k++){ 
                res.at(i).at(j) += mata.at(i).at(k) *  matb.at(k).at(j);
            } 
        } 
    } 
};
double determinant( double matrix[6][6], int n) {   
   double det = 0;
   double submatrix[6][6];
   if (n == 2)
      return ((matrix[0][0] * matrix[1][1]) - (matrix[1][0] * matrix[0][1]));
   else {
      for (int x = 0; x < n; x++) {
            int subi = 0; 
            for (int i = 1; i < n; i++) {
               int subj = 0;
               for (int j = 0; j < n; j++) {
                  if (j == x)
                  continue;
                  submatrix[subi][subj] = matrix[i][j];
                  subj++;
               }
               subi++;
            }
            det = det + (pow(-1, x) * matrix[0][x] * determinant( submatrix, n - 1 ));
      }
   }
   return det;
};
void subtract(vector<double> &A, vector<double> &B, vector<double> &C)  
{  C.resize(A.size());
    for (int i = 0; i < C.size(); i++){  
            C.at(i) = A.at(i) - B.at(i);}  
            
};   
double deg_to_rad(double angle_param) {
    return angle_param * (M_PI/180);
};
void crossProd(vector<double> &bruh, vector<double> &bruh2, vector <double> &boii)   
{ 
  boii.resize(bruh.size());
    boii.at(0) = bruh.at(1) * bruh2.at(2) - bruh.at(2) * bruh2.at(1); 
    boii.at(1) = bruh.at(0) * bruh2.at(2) - bruh.at(2) * bruh2.at(0); 
    boii.at(2) = bruh.at(0) * bruh2.at(1) - bruh.at(1) * bruh2.at(0); 
};

void transform(double theta, double a, double d, double alpha, vector<vector<double>> &T) {
   T.resize(N);
   for(int i = 0; i < T.size(); i++){
       T.at(i).resize(N);
   }
    T.at(0).at(0) = cos(theta); 
    T.at(0).at(1) = -sin(theta) * cos(alpha); 
    T.at(0).at(2) = sin(theta) * sin(alpha); 
    T.at(0).at(3) = a * cos(theta);

    T.at(1).at(0) = sin(theta);
    T.at(1).at(1) = cos(theta) * cos(alpha);
    T.at(1).at(2) = -cos(theta) * sin(alpha);
    T.at(1).at(3) = a * sin(theta);

    T.at(2).at(0) = 0;
    T.at(2).at(1) = sin(alpha);
    T.at(2).at(2) = cos(alpha);
    T.at(2).at(3) = d;

    T.at(3).at(0) = 0;
    T.at(3).at(1) = 0;
    T.at(3).at(2) = 0;
    T.at(3).at(3) = 1;
};

int main() {
    int count=0;
    int output[10];
    double theta1, theta2, theta3, theta4, theta5, theta6;
    string filename;
    cout << "Enter filename for input: " << endl;
    cin >> filename;
    ifstream inFile(filename);
    string line;
    while(getline(inFile, line))
    {
      if (!inFile) {
        cerr << "Unable to open file";
        exit(1); } 
    
    inFile >> theta1 >> theta2 >> theta3 >> theta4 >> theta5 >> theta6;
    

    vector<vector<double>> h1; 
    vector<vector<double>> h2;
    vector<vector<double>> h3;
    vector<vector<double>> h4;
    vector<vector<double>> h5;
    vector<vector<double>> h6;

    transform(deg_to_rad(theta1), 0.0, 0.1625, deg_to_rad(90), h1);
    transform(deg_to_rad(theta2), -0.425, 0.0, 0.0, h2);
    transform(deg_to_rad(theta3), -0.3922, 0.0, 0.0, h3);
    transform(deg_to_rad(theta4), 0.0, 0.1333, deg_to_rad(90), h4);
    transform(deg_to_rad(theta5), 0.0, 0.0997, deg_to_rad(-90), h5);
    transform(deg_to_rad(theta6), 0.0, 0.0996, 0.0, h6);
    
    

    vector<vector<double>> t2;
    vector<vector<double>> t3;
    vector<vector<double>> t4;
    vector<vector<double>> t5;
    vector<vector<double>> t6;
    
    multiply (h1,h2,t2);
    multiply (t2,h3,t3);
    multiply (t3,h4,t4);
    multiply (t4,h5,t5);
    multiply (t5,h6,t6);
    
    vector<double> z0 = { 0.0, 0.0, 1.0 };
    vector<double> z1 = { h1.at(0).at(2), h1.at(1).at(2), h1.at(2).at(2) };
    vector<double> z2 = { t2.at(0).at(2), t2.at(1).at(2), t2.at(2).at(2) };
    vector<double> z3 = { t3.at(0).at(2), t3.at(1).at(2), t3.at(2).at(2) };
    vector<double> z4 = { t4.at(0).at(2), t4.at(1).at(2), t4.at(2).at(2) };
    vector<double> z5 = { t5.at(0).at(2), t5.at(1).at(2), t5.at(2).at(2) };

    vector<double> o0 = { 0.0, 0.0, 0.0 };
    vector<double> o1 = { h1.at(0).at(3), h1.at(1).at(3), h1.at(2).at(3) };
    vector<double> o2 = { t2.at(0).at(3), t2.at(1).at(3), t2.at(2).at(3) };
    vector<double> o3 = { t3.at(0).at(3), t3.at(1).at(3), t3.at(2).at(3) };
    vector<double> o4 = { t4.at(0).at(3), t4.at(1).at(3), t4.at(2).at(3) };
    vector<double> o5 = { t5.at(0).at(3), t5.at(1).at(3), t5.at(2).at(3) };
    vector<double> o6 = { t6.at(0).at(3), t6.at(1).at(3), t6.at(2).at(3) };
    
    vector<double> j0;
    vector<double> j1;
    vector<double> j2;
    vector<double> j3;
    vector<double> j4;
    vector<double> j5;
    vector<double> s0;
    vector<double> s1;
    vector<double> s2;
    vector<double> s3;
    vector<double> s4;
    vector<double> s5;

    subtract(o6,o0,s0);
    subtract(o6,o1,s1);
    subtract(o6,o2,s2);
    subtract(o6,o3,s3);
    subtract(o6,o4,s4);
    subtract(o6,o5,s5);

    crossProd(z0,s0,j0);
    crossProd(z1,s1,j1);
    crossProd(z2,s2,j2);
    crossProd(z3,s3,j3);
    crossProd(z4,s4,j4);
    crossProd(z5,s5,j5); 
     
    double jacobian[6][6]= {  
                                { j0.at(0), j1.at(0), j2.at(0), j3.at(0), j4.at(0), j5.at(0) },
                                { j0.at(1), j1.at(1), j2.at(1), j3.at(1), j4.at(1), j5.at(1) },
                                { j0.at(2), j1.at(2), j2.at(2), j3.at(2), j4.at(2), j5.at(2) },
                                { z0.at(0), z1.at(0), z2.at(0), z3.at(0), z4.at(0), z5.at(0) },
                                { z0.at(1), z1.at(1), z2.at(1), z3.at(1), z4.at(1), z5.at(1) },
                                { z0.at(2), z1.at(2), z2.at(2), z3.at(2), z4.at(2), z5.at(2) } 
                            };
    
    
    double det = determinant(jacobian, 6); 
    
    if(det < 0.001) {
        //cout << "1" << endl << endl;
        output[count]=1;
    }
    else {
        //cout << "0" << endl << endl;
        output[count] =0;
    }
    count++;
}
inFile.close();
cout<<"writing to output.txt"<<endl;
ofstream myfile1;
    myfile1.open("output.txt");
for(int i =0; i< 9; i++){
    myfile1 << output[i]<<endl;
}
myfile1<<"1"<<endl;
myfile1.close();
return 0;

}